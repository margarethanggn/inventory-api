package com.example.inventory_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
